#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Transaction {
    string type;
    double amount;
};

struct Profile {
    string name;
    string phoneNumber;
    double balance;
    vector<Transaction> transactionHistory;
};

void displayMainMenu() {
    cout << "Welcome to MyTelecom USSD System" << endl;
    cout << "1. Balance Inquiry" << endl;
    cout << "2. Account Recharge" << endl;
    cout << "3. Transaction History" << endl;
    cout << "4. View Profile" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice: ";
}

void balanceInquiry(const Profile& userProfile) {
    cout << "Your current balance is " << userProfile.balance << " USD" << endl;
}

void accountRecharge(Profile& userProfile) {
    double rechargeAmount;
    cout << "Enter the recharge amount: ";
    cin >> rechargeAmount;

    userProfile.balance += rechargeAmount;

    Transaction rechargeTransaction;
    rechargeTransaction.type = "Recharge";
    rechargeTransaction.amount = rechargeAmount;

    userProfile.transactionHistory.push_back(rechargeTransaction);

    cout << "Recharge of " << rechargeAmount << " USD successful. Your new balance is " << userProfile.balance << " USD" << endl;
}

void transactionHistory(const Profile& userProfile) {
    cout << "Transaction History:" << endl;

    
}

void viewProfile(const Profile& userProfile) {
    cout << "Name: " << userProfile.name << endl;
    cout << "Phone Number: " << userProfile.phoneNumber << endl;
    cout << "Balance: " << userProfile.balance << " USD" << endl;
}

int main() {
    Profile userProfile;
    userProfile.name = "John Doe";
    userProfile.phoneNumber = "123456789";
    userProfile.balance = 50.0;

    int choice;

    while (true) {
        displayMainMenu();
        cin >> choice;

        switch (choice) {
            case 1:
                balanceInquiry(userProfile);
                break;
            case 2:
                accountRecharge(userProfile);
                break;
            case 3:
                transactionHistory(userProfile);
                break;
            case 4:
                viewProfile(userProfile);
                break;
            case 0:
                cout << "Thank you for using MyTelecom!" << endl;
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }

        cout << endl;
    }
}

